// EduConnect - Complete Education Platform
// Full-featured learning management system

// ==========================================
// DATA STORAGE
// ==========================================
class DataStore {
    constructor() {
        this.init();
    }

    init() {
        if (!localStorage.getItem('eduConnect_initialized')) {
            this.resetToDefaults();
            localStorage.setItem('eduConnect_initialized', 'true');
        }
    }

    resetToDefaults() {
        // Sample courses
        const courses = [
            {id: 'c001', title: 'Introduction to Python Programming', category: 'programming', level: 'beginner', price: 49, rating: 4.8, students: 12500, instructor: 'Dr. Sarah Chen', duration: '8 hours', lessons: 42, image: '💻'},
            {id: 'c002', title: 'Advanced Mathematics', category: 'mathematics', level: 'advanced', price: 79, rating: 4.9, students: 8200, instructor: 'Prof. Michael Roberts', duration: '12 hours', lessons: 56, image: '📐'},
            {id: 'c003', title: 'Spanish for Beginners', category: 'languages', level: 'beginner', price: 39, rating: 4.7, students: 15600, instructor: 'Maria Garcia', duration: '10 hours', lessons: 48, image: '🗣️'},
            {id: 'c004', title: 'Data Science Fundamentals', category: 'programming', level: 'intermediate', price: 99, rating: 4.9, students: 9800, instructor: 'Dr. James Wilson', duration: '15 hours', lessons: 68, image: '📊'},
            {id: 'c005', title: 'Physics 101', category: 'science', level: 'beginner', price: 59, rating: 4.6, students: 7200, instructor: 'Dr. Emily Taylor', duration: '14 hours', lessons: 52, image: '⚛️'},
            {id: 'c006', title: 'Digital Marketing Mastery', category: 'business', level: 'intermediate', price: 89, rating: 4.8, students: 11400, instructor: 'John Anderson', duration: '11 hours', lessons: 45, image: '📱'},
            {id: 'c007', title: 'Graphic Design Basics', category: 'arts', level: 'beginner', price: 69, rating: 4.7, students: 13200, instructor: 'Lisa Martinez', duration: '9 hours', lessons: 38, image: '🎨'},
            {id: 'c008', title: 'Web Development Bootcamp', category: 'programming', level: 'intermediate', price: 129, rating: 4.9, students: 18900, instructor: 'Alex Thompson', duration: '25 hours', lessons: 98, image: '🌐'},
            {id: 'c009', title: 'Business Strategy', category: 'business', level: 'advanced', price: 149, rating: 4.8, students: 6500, instructor: 'Robert Brown', duration: '18 hours', lessons: 72, image: '💼'},
            {id: 'c010', title: 'French Intermediate', category: 'languages', level: 'intermediate', price: 59, rating: 4.6, students: 8900, instructor: 'Pierre Dubois', duration: '12 hours', lessons: 54, image: '🇫🇷'}
        ];

        // Sample tutors
        const tutors = [
            {id: 't001', name: 'Dr. Sarah Chen', subject: 'programming', rating: 4.9, reviews: 245, rate: 45, experience: 8, students: 1200, languages: 'English, Chinese', avatar: 'https://ui-avatars.com/api/?name=Sarah+Chen&background=6366f1&color=fff'},
            {id: 't002', name: 'Prof. Michael Roberts', subject: 'mathematics', rating: 5.0, reviews: 312, rate: 55, experience: 12, students: 980, languages: 'English', avatar: 'https://ui-avatars.com/api/?name=Michael+Roberts&background=10b981&color=fff'},
            {id: 't003', name: 'Maria Garcia', subject: 'languages', rating: 4.8, reviews: 198, rate: 35, experience: 6, students: 1450, languages: 'Spanish, English', avatar: 'https://ui-avatars.com/api/?name=Maria+Garcia&background=f59e0b&color=fff'},
            {id: 't004', name: 'Dr. James Wilson', subject: 'science', rating: 4.9, reviews: 276, rate: 50, experience: 10, students: 890, languages: 'English', avatar: 'https://ui-avatars.com/api/?name=James+Wilson&background=ef4444&color=fff'},
            {id: 't005', name: 'Emily Taylor', subject: 'business', rating: 4.7, reviews: 189, rate: 40, experience: 7, students: 1100, languages: 'English, German', avatar: 'https://ui-avatars.com/api/?name=Emily+Taylor&background=8b5cf6&color=fff'},
            {id: 't006', name: 'John Anderson', subject: 'programming', rating: 4.8, reviews: 234, rate: 48, experience: 9, students: 1340, languages: 'English', avatar: 'https://ui-avatars.com/api/?name=John+Anderson&background=06b6d4&color=fff'}
        ];

        // Sample sessions
        const sessions = [
            {id: 's001', tutorId: 't001', tutorName: 'Dr. Sarah Chen', subject: 'Python Programming', date: '2025-12-28', time: '10:00 AM', duration: 60, status: 'upcoming'},
            {id: 's002', tutorId: 't002', tutorName: 'Prof. Michael Roberts', subject: 'Calculus', date: '2025-12-30', time: '2:00 PM', duration: 60, status: 'upcoming'}
        ];

        // Enrolled courses
        const enrolled = ['c001', 'c003'];

        // Certificates
        const certificates = [
            {id: 'cert001', courseName: 'JavaScript Fundamentals', date: '2025-11-15', score: 92},
            {id: 'cert002', courseName: 'English Grammar', date: '2025-10-20', score: 88}
        ];

        // Notifications
        const notifications = [
            {id: 'n001', title: 'Session Reminder', message: 'Your Python session is tomorrow at 10 AM', time: '2 hours ago', read: false},
            {id: 'n002', title: 'New Course Available', message: 'Check out Advanced React Development', time: '5 hours ago', read: false},
            {id: 'n003', title: 'Certificate Earned', message: 'Congratulations! You completed JavaScript Basics', time: '1 day ago', read: true}
        ];

        localStorage.setItem('courses', JSON.stringify(courses));
        localStorage.setItem('tutors', JSON.stringify(tutors));
        localStorage.setItem('sessions', JSON.stringify(sessions));
        localStorage.setItem('enrolled', JSON.stringify(enrolled));
        localStorage.setItem('certificates', JSON.stringify(certificates));
        localStorage.setItem('notifications', JSON.stringify(notifications));
    }

    get(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }

    set(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    add(key, item) {
        const items = this.get(key) || [];
        items.push(item);
        this.set(key, items);
        return item;
    }
}

const dataStore = new DataStore();

// ==========================================
// AUTH SYSTEM
// ==========================================
class AuthSystem {
    constructor() {
        this.currentUser = this.getUser();
        this.updateUI();
    }

    getUser() {
        const user = localStorage.getItem('currentUser');
        return user ? JSON.parse(user) : null;
    }

    setUser(user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
        this.currentUser = user;
        this.updateUI();
    }

    signIn(email, password) {
        if (email && password) {
            const user = {
                id: 'user_' + Date.now(),
                name: email.split('@')[0],
                email: email,
                role: 'student',
                avatar: `https://ui-avatars.com/api/?name=${email.split('@')[0]}&background=6366f1&color=fff`
            };
            this.setUser(user);
            return { success: true, user };
        }
        return { success: false, error: 'Invalid credentials' };
    }

    signUp(name, email, password, role) {
        if (name && email && password) {
            const user = {
                id: 'user_' + Date.now(),
                name: name,
                email: email,
                role: role || 'student',
                avatar: `https://ui-avatars.com/api/?name=${name}&background=6366f1&color=fff`
            };
            this.setUser(user);
            return { success: true, user };
        }
        return { success: false, error: 'Invalid data' };
    }

    signOut() {
        localStorage.removeItem('currentUser');
        this.currentUser = null;
        this.updateUI();
    }

    isAuthenticated() {
        return this.currentUser !== null;
    }

    updateUI() {
        const authBtn = document.getElementById('auth-btn');
        const userMenu = document.getElementById('user-menu');

        if (this.isAuthenticated()) {
            authBtn.style.display = 'none';
            userMenu.style.display = 'flex';
            document.getElementById('user-name').textContent = this.currentUser.name;
            if (userMenu.querySelector('.user-avatar')) {
                userMenu.querySelector('.user-avatar').src = this.currentUser.avatar;
            }
        } else {
            authBtn.style.display = 'block';
            userMenu.style.display = 'none';
        }
    }

    requireAuth(callback) {
        if (this.isAuthenticated()) {
            callback();
        } else {
            showToast('Please sign in to continue', 'info');
            openModal('authModal');
        }
    }
}

const auth = new AuthSystem();

// ==========================================
// NAVIGATION
// ==========================================
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });

    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
    }

    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === '#' + sectionId) {
            link.classList.add('active');
        }
    });

    loadSectionData(sectionId);
}

function loadSectionData(sectionId) {
    switch(sectionId) {
        case 'courses':
            loadCourses();
            break;
        case 'tutors':
            loadTutors();
            break;
        case 'my-learning':
            loadMyLearning();
            break;
    }
}

// ==========================================
// COURSES
// ==========================================
function loadCourses() {
    const courses = dataStore.get('courses') || [];
    const grid = document.getElementById('courses-grid');

    grid.innerHTML = courses.map(course => `
        <div class="course-card" onclick="openCourse('${course.id}')">
            <div class="course-image">${course.image}</div>
            <div class="course-content">
                <span class="course-category">${course.category}</span>
                <div class="course-title">${course.title}</div>
                <div class="course-instructor">By ${course.instructor}</div>
                <div class="course-meta">
                    <div class="course-rating">
                        <span class="stars">⭐</span>
                        <span>${course.rating} (${course.students.toLocaleString()})</span>
                    </div>
                    <div class="course-price">$${course.price}</div>
                </div>
            </div>
        </div>
    `).join('');
}

function filterCourses() {
    const searchTerm = document.getElementById('course-search').value.toLowerCase();
    const category = document.getElementById('course-category').value;
    const level = document.getElementById('course-level').value;
    const price = document.getElementById('course-price').value;

    let courses = dataStore.get('courses') || [];

    courses = courses.filter(course => {
        const matchesSearch = course.title.toLowerCase().includes(searchTerm);
        const matchesCategory = category === 'all' || course.category === category;
        const matchesLevel = level === 'all' || course.level === level;
        const matchesPrice = price === 'all' || 
            (price === 'free' && course.price === 0) ||
            (price === 'paid' && course.price > 0);
        return matchesSearch && matchesCategory && matchesLevel && matchesPrice;
    });

    const grid = document.getElementById('courses-grid');
    grid.innerHTML = courses.map(course => `
        <div class="course-card" onclick="openCourse('${course.id}')">
            <div class="course-image">${course.image}</div>
            <div class="course-content">
                <span class="course-category">${course.category}</span>
                <div class="course-title">${course.title}</div>
                <div class="course-instructor">By ${course.instructor}</div>
                <div class="course-meta">
                    <div class="course-rating">
                        <span class="stars">⭐</span>
                        <span>${course.rating}</span>
                    </div>
                    <div class="course-price">$${course.price}</div>
                </div>
            </div>
        </div>
    `).join('');
}

function openCourse(courseId) {
    const courses = dataStore.get('courses') || [];
    const course = courses.find(c => c.id === courseId);

    if (course) {
        const enrolled = dataStore.get('enrolled') || [];
        const isEnrolled = enrolled.includes(courseId);

        const content = `
            <div style="padding: 2rem;">
                <div class="course-image" style="width: 100%; height: 200px; margin-bottom: 2rem;">${course.image}</div>
                <h2>${course.title}</h2>
                <p style="color: var(--gray-600); margin: 1rem 0;">By ${course.instructor}</p>
                <div style="display: flex; gap: 2rem; margin: 1.5rem 0;">
                    <div><strong>⭐ ${course.rating}</strong> rating</div>
                    <div><strong>${course.students.toLocaleString()}</strong> students</div>
                    <div><strong>${course.duration}</strong></div>
                    <div><strong>${course.lessons}</strong> lessons</div>
                </div>
                <div style="background: var(--gray-50); padding: 1.5rem; border-radius: 10px; margin: 1.5rem 0;">
                    <h3>What you'll learn</h3>
                    <ul style="margin-top: 1rem; padding-left: 1.5rem;">
                        <li>Master the fundamentals and advanced concepts</li>
                        <li>Build real-world projects from scratch</li>
                        <li>Get lifetime access to all course materials</li>
                        <li>Earn a certificate of completion</li>
                    </ul>
                </div>
                <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button class="btn-secondary" onclick="closeModal('courseDetailModal')">Close</button>
                    ${isEnrolled ? 
                        '<button class="btn-primary" onclick="startCourse('' + course.id + '')"><i class="fas fa-play"></i> Continue Learning</button>' :
                        '<button class="btn-primary" onclick="enrollCourse('' + course.id + '')"><i class="fas fa-shopping-cart"></i> Enroll Now - $' + course.price + '</button>'}
                </div>
            </div>
        `;
        document.getElementById('course-detail-content').innerHTML = content;
        openModal('courseDetailModal');
    }
}

function enrollCourse(courseId) {
    auth.requireAuth(() => {
        const enrolled = dataStore.get('enrolled') || [];
        if (!enrolled.includes(courseId)) {
            enrolled.push(courseId);
            dataStore.set('enrolled', enrolled);
            showToast('Successfully enrolled in course!', 'success');
            closeModal('courseDetailModal');
            openCourse(courseId);
        }
    });
}

function startCourse(courseId) {
    showToast('Starting course...', 'info');
    closeModal('courseDetailModal');
}

function filterByCategory(category) {
    document.getElementById('course-category').value = category;
    showSection('courses');
    setTimeout(() => filterCourses(), 100);
}

// ==========================================
// TUTORS
// ==========================================
function loadTutors() {
    const tutors = dataStore.get('tutors') || [];
    const grid = document.getElementById('tutors-grid');

    grid.innerHTML = tutors.map(tutor => `
        <div class="tutor-card">
            <div class="tutor-header">
                <img src="${tutor.avatar}" alt="${tutor.name}" class="tutor-avatar">
                <div class="tutor-info">
                    <h3>${tutor.name}</h3>
                    <div class="tutor-subject">${formatSubject(tutor.subject)}</div>
                    <div class="tutor-rating">
                        <span class="stars">${'⭐'.repeat(Math.floor(tutor.rating))}</span>
                        <span>${tutor.rating} (${tutor.reviews})</span>
                    </div>
                </div>
            </div>
            <div class="tutor-stats">
                <div class="stat">
                    <div class="stat-value">${tutor.experience}</div>
                    <div class="stat-label">Years</div>
                </div>
                <div class="stat">
                    <div class="stat-value">${tutor.students}</div>
                    <div class="stat-label">Students</div>
                </div>
                <div class="stat">
                    <div class="stat-value">$${tutor.rate}</div>
                    <div class="stat-label">/hour</div>
                </div>
            </div>
            <button class="btn-primary" style="width: 100%;" onclick="bookTutor('${tutor.id}')">
                <i class="fas fa-calendar-plus"></i> Book Session
            </button>
        </div>
    `).join('');
}

function filterTutors() {
    const searchTerm = document.getElementById('tutor-search').value.toLowerCase();
    const subject = document.getElementById('tutor-subject').value;
    const rating = document.getElementById('tutor-rating').value;
    const price = document.getElementById('tutor-price').value;

    let tutors = dataStore.get('tutors') || [];

    tutors = tutors.filter(tutor => {
        const matchesSearch = tutor.name.toLowerCase().includes(searchTerm);
        const matchesSubject = subject === 'all' || tutor.subject === subject;
        const matchesRating = rating === 'all' || tutor.rating >= parseInt(rating);
        const matchesPrice = price === 'all' || 
            (price === 'budget' && tutor.rate < 30) ||
            (price === 'mid' && tutor.rate >= 30 && tutor.rate <= 60) ||
            (price === 'premium' && tutor.rate > 60);
        return matchesSearch && matchesSubject && matchesRating && matchesPrice;
    });

    const grid = document.getElementById('tutors-grid');
    grid.innerHTML = tutors.map(tutor => `
        <div class="tutor-card">
            <div class="tutor-header">
                <img src="${tutor.avatar}" alt="${tutor.name}" class="tutor-avatar">
                <div class="tutor-info">
                    <h3>${tutor.name}</h3>
                    <div class="tutor-subject">${formatSubject(tutor.subject)}</div>
                    <div class="tutor-rating">
                        <span class="stars">${'⭐'.repeat(Math.floor(tutor.rating))}</span>
                        <span>${tutor.rating}</span>
                    </div>
                </div>
            </div>
            <div class="tutor-stats">
                <div class="stat">
                    <div class="stat-value">${tutor.experience}</div>
                    <div class="stat-label">Years</div>
                </div>
                <div class="stat">
                    <div class="stat-value">${tutor.students}</div>
                    <div class="stat-label">Students</div>
                </div>
                <div class="stat">
                    <div class="stat-value">$${tutor.rate}</div>
                    <div class="stat-label">/hour</div>
                </div>
            </div>
            <button class="btn-primary" style="width: 100%;" onclick="bookTutor('${tutor.id}')">
                <i class="fas fa-calendar-plus"></i> Book Session
            </button>
        </div>
    `).join('');
}

function bookTutor(tutorId) {
    auth.requireAuth(() => {
        document.getElementById('session-tutor').value = tutorId;
        populateTutorSelect();
        openModal('bookSessionModal');
    });
}

function formatSubject(subject) {
    const subjects = {
        'mathematics': 'Mathematics',
        'science': 'Science',
        'programming': 'Programming',
        'languages': 'Languages',
        'business': 'Business',
        'arts': 'Arts & Design'
    };
    return subjects[subject] || subject;
}

// ==========================================
// MY LEARNING
// ==========================================
function loadMyLearning() {
    loadEnrolledCourses();
    loadSessions();
    loadCertificates();
    loadProgress();
}

function loadEnrolledCourses() {
    const enrolled = dataStore.get('enrolled') || [];
    const courses = dataStore.get('courses') || [];
    const enrolledCourses = courses.filter(c => enrolled.includes(c.id));

    const grid = document.getElementById('enrolled-courses');
    if (enrolledCourses.length === 0) {
        grid.innerHTML = '<p style="text-align: center; padding: 3rem;">No enrolled courses yet. Browse our catalog!</p>';
        return;
    }

    grid.innerHTML = enrolledCourses.map(course => `
        <div class="course-card" onclick="startCourse('${course.id}')">
            <div class="course-image">${course.image}</div>
            <div class="course-content">
                <div class="course-title">${course.title}</div>
                <div class="progress-bar" style="margin: 1rem 0;">
                    <div class="progress-fill" style="width: ${Math.floor(Math.random() * 100)}%;"></div>
                </div>
                <button class="btn-primary" style="width: 100%;">Continue Learning</button>
            </div>
        </div>
    `).join('');
}

function loadSessions() {
    const sessions = dataStore.get('sessions') || [];
    const list = document.getElementById('sessions-list');

    if (sessions.length === 0) {
        list.innerHTML = '<p style="text-align: center; padding: 3rem;">No sessions booked</p>';
        return;
    }

    list.innerHTML = sessions.map(session => {
        const date = new Date(session.date);
        return `
            <div class="session-card">
                <div class="session-time">
                    <div style="font-size: 2rem; font-weight: bold;">${date.getDate()}</div>
                    <div>${date.toLocaleString('default', { month: 'short' })}</div>
                </div>
                <div class="session-info">
                    <h3>${session.tutorName}</h3>
                    <p><i class="fas fa-book"></i> ${session.subject}</p>
                    <p><i class="fas fa-clock"></i> ${session.time} (${session.duration} min)</p>
                </div>
                <div class="session-actions">
                    <button class="btn-primary">Join Session</button>
                </div>
            </div>
        `;
    }).join('');
}

function loadCertificates() {
    const certificates = dataStore.get('certificates') || [];
    const grid = document.getElementById('certificates-grid');

    if (certificates.length === 0) {
        grid.innerHTML = '<p style="text-align: center; padding: 3rem;">No certificates yet. Complete courses to earn them!</p>';
        return;
    }

    grid.innerHTML = certificates.map(cert => `
        <div class="certificate-card">
            <div class="certificate-icon">🏆</div>
            <h3>${cert.courseName}</h3>
            <p>Completed: ${cert.date}</p>
            <p>Score: ${cert.score}%</p>
            <button class="btn-primary" style="margin-top: 1rem;">Download Certificate</button>
        </div>
    `).join('');
}

function loadProgress() {
    const dashboard = document.getElementById('progress-dashboard');
    dashboard.innerHTML = `
        <div class="progress-card">
            <h3>Learning Streak</h3>
            <div style="font-size: 3rem; text-align: center; margin: 1rem 0;">🔥 15</div>
            <p style="text-align: center;">Days in a row!</p>
        </div>
        <div class="progress-card">
            <h3>Courses Completed</h3>
            <div style="font-size: 3rem; text-align: center; margin: 1rem 0;">8</div>
            <p style="text-align: center;">Out of 12 enrolled</p>
        </div>
        <div class="progress-card">
            <h3>Total Learning Time</h3>
            <div style="font-size: 3rem; text-align: center; margin: 1rem 0;">124h</div>
            <p style="text-align: center;">This month</p>
        </div>
    `;
}

function switchLearningTab(tab) {
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.querySelectorAll('.tab').forEach(t => {
        t.classList.remove('active');
    });

    document.getElementById(tab + '-tab').classList.add('active');
    event.target.classList.add('active');
}

// ==========================================
// PRICING
// ==========================================
function selectPlan(plan) {
    auth.requireAuth(() => {
        showToast(`Proceeding to payment for ${plan} plan...`, 'info');
    });
}

// ==========================================
// MODALS & UI
// ==========================================
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        if (modalId === 'bookSessionModal') {
            populateTutorSelect();
        }
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

function populateTutorSelect() {
    const tutors = dataStore.get('tutors') || [];
    const select = document.getElementById('session-tutor');
    select.innerHTML = '<option value="">Choose a tutor...</option>' +
        tutors.map(t => `<option value="${t.id}">${t.name} - ${formatSubject(t.subject)} ($${t.rate}/hr)</option>`).join('');
}

function switchAuthTab(tab) {
    document.querySelectorAll('.auth-form').forEach(form => {
        form.classList.remove('active');
    });
    document.querySelectorAll('.auth-tab').forEach(t => {
        t.classList.remove('active');
    });

    if (tab === 'signin') {
        document.getElementById('signin-form').classList.add('active');
        document.querySelectorAll('.auth-tab')[0].classList.add('active');
    } else {
        document.getElementById('signup-form').classList.add('active');
        document.querySelectorAll('.auth-tab')[1].classList.add('active');
    }
}

function loadNotifications() {
    const notifications = dataStore.get('notifications') || [];
    const list = document.getElementById('notifications-list');
    const count = document.getElementById('notif-count');

    const unreadCount = notifications.filter(n => !n.read).length;
    count.textContent = unreadCount;
    count.style.display = unreadCount > 0 ? 'block' : 'none';

    list.innerHTML = notifications.map(notif => `
        <div class="notification-item ${notif.read ? '' : 'unread'}">
            <h4>${notif.title}</h4>
            <p>${notif.message}</p>
            <time>${notif.time}</time>
        </div>
    `).join('');
}

function markAllRead() {
    const notifications = dataStore.get('notifications') || [];
    notifications.forEach(n => n.read = true);
    dataStore.set('notifications', notifications);
    loadNotifications();
}

function toggleNotificationPanel() {
    const panel = document.getElementById('notificationPanel');
    panel.classList.toggle('active');
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };

    toast.innerHTML = `
        <i class="fas ${icons[type]}"></i>
        <span>${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// ==========================================
// EVENT LISTENERS
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const sectionId = this.getAttribute('href').substring(1);
            showSection(sectionId);
        });
    });

    // Auth
    document.getElementById('auth-btn').addEventListener('click', () => {
        openModal('authModal');
    });

    document.getElementById('notifications-btn').addEventListener('click', () => {
        toggleNotificationPanel();
    });

    document.getElementById('signin-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('signin-email').value;
        const password = document.getElementById('signin-password').value;

        const result = auth.signIn(email, password);
        if (result.success) {
            closeModal('authModal');
            showToast('Welcome back!', 'success');
        }
    });

    document.getElementById('signup-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('signup-name').value;
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;
        const role = document.getElementById('signup-role').value;

        const result = auth.signUp(name, email, password, role);
        if (result.success) {
            closeModal('authModal');
            showToast('Account created!', 'success');
        }
    });

    document.getElementById('book-session-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const tutorId = document.getElementById('session-tutor').value;
        const subject = document.getElementById('session-subject').value;
        const datetime = document.getElementById('session-datetime').value;
        const duration = document.getElementById('session-duration').value;
        const topic = document.getElementById('session-topic').value;

        if (!tutorId || !subject || !datetime) {
            showToast('Please fill all fields', 'error');
            return;
        }

        const tutors = dataStore.get('tutors') || [];
        const tutor = tutors.find(t => t.id === tutorId);

        const newSession = {
            id: 's_' + Date.now(),
            tutorId: tutorId,
            tutorName: tutor.name,
            subject: subject,
            date: datetime.split('T')[0],
            time: datetime.split('T')[1],
            duration: parseInt(duration),
            status: 'upcoming'
        };

        dataStore.add('sessions', newSession);
        closeModal('bookSessionModal');
        showToast('Session booked successfully!', 'success');
    });

    document.getElementById('become-tutor-form').addEventListener('submit', function(e) {
        e.preventDefault();
        showToast('Application submitted! We will review and contact you soon.', 'success');
        closeModal('becomeTutorModal');
    });

    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });
    });

    document.getElementById('user-menu').addEventListener('click', function() {
        if (confirm('Sign out?')) {
            auth.signOut();
            showToast('Signed out', 'info');
            showSection('home');
        }
    });

    document.getElementById('search-btn').addEventListener('click', function() {
        showToast('Global search coming soon!', 'info');
    });

    // Initialize
    loadNotifications();
    showSection('home');
});
